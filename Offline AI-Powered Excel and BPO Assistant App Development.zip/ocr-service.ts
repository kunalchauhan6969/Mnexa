/**
 * OCR Service - Text Extraction from Images
 * 
 * This service handles optical character recognition using ML Kit.
 * In production, this would use the native ML Kit Text Recognition API.
 * For now, it provides mock OCR responses.
 */

export interface OCRResult {
  success: boolean;
  extractedText: string;
  confidence: number;
  blocks: Array<{
    text: string;
    confidence: number;
    bounds: { x: number; y: number; width: number; height: number };
  }>;
  detectedLanguages: string[];
}

export interface TextBlock {
  text: string;
  confidence: number;
  bounds: { x: number; y: number; width: number; height: number };
}

/**
 * Initialize OCR service (mock implementation)
 */
export async function initializeOCR(): Promise<boolean> {
  try {
    // In production, this would initialize ML Kit
    console.log("OCR Service initialized (mock mode)");
    return true;
  } catch (error) {
    console.error("Failed to initialize OCR:", error);
    return false;
  }
}

/**
 * Extract text from an image
 */
export async function extractTextFromImage(imageUri: string): Promise<OCRResult> {
  try {
    // Mock OCR response - in production, this would call ML Kit
    // Simulate processing delay
    await new Promise((resolve) => setTimeout(resolve, 1000));

    // Mock extracted text from an Excel sheet
    const mockExtractedText = `Sales Summary Q1 2024
    
Product | January | February | March | Total
Laptop | 150 | 175 | 200 | =SUM(B2:D2)
Phone | 300 | 320 | 350 | =SUM(B3:D3)
Tablet | 100 | 120 | 140 | =SUM(B4:D4)
Total | =SUM(B2:B4) | =SUM(C2:C4) | =SUM(D2:D4) | =SUM(E2:E4)

Average Price: =AVERAGE(B2:D4)
Max Sales: =MAX(B2:D4)
Min Sales: =MIN(B2:D4)`;

    return {
      success: true,
      extractedText: mockExtractedText,
      confidence: 0.92,
      blocks: [
        {
          text: "Sales Summary Q1 2024",
          confidence: 0.98,
          bounds: { x: 10, y: 10, width: 300, height: 30 },
        },
        {
          text: "Product | January | February | March | Total",
          confidence: 0.95,
          bounds: { x: 10, y: 50, width: 400, height: 20 },
        },
        {
          text: "Laptop | 150 | 175 | 200 | =SUM(B2:D2)",
          confidence: 0.90,
          bounds: { x: 10, y: 75, width: 400, height: 20 },
        },
      ],
      detectedLanguages: ["en"],
    };
  } catch (error) {
    console.error("Error extracting text:", error);
    return {
      success: false,
      extractedText: "",
      confidence: 0,
      blocks: [],
      detectedLanguages: [],
    };
  }
}

/**
 * Detect formulas in extracted text
 */
export function detectFormulas(text: string): string[] {
  const formulaPattern = /=([A-Z]+)\([^)]*\)/gi;
  const matches = text.match(formulaPattern) || [];
  return [...new Set(matches)]; // Remove duplicates
}

/**
 * Validate formulas for common errors
 */
export function validateFormulas(formulas: string[]): Array<{
  formula: string;
  isValid: boolean;
  errors: string[];
}> {
  return formulas.map((formula) => {
    const errors: string[] = [];

    // Check for common formula errors
    if (!formula.startsWith("=")) {
      errors.push("Formula must start with '='");
    }

    if (formula.includes("()")) {
      errors.push("Empty function parentheses");
    }

    if ((formula.match(/\(/g) || []).length !== (formula.match(/\)/g) || []).length) {
      errors.push("Mismatched parentheses");
    }

    // Check for unclosed quotes
    const singleQuotes = (formula.match(/'/g) || []).length;
    const doubleQuotes = (formula.match(/"/g) || []).length;
    if (singleQuotes % 2 !== 0 || doubleQuotes % 2 !== 0) {
      errors.push("Unclosed quotes");
    }

    return {
      formula,
      isValid: errors.length === 0,
      errors,
    };
  });
}

/**
 * Extract cell references from a formula
 */
export function extractCellReferences(formula: string): string[] {
  // Match patterns like A1, B2:C5, $A$1, etc.
  const cellPattern = /\$?[A-Z]+\$?\d+(?::\$?[A-Z]+\$?\d+)?/g;
  return formula.match(cellPattern) || [];
}

/**
 * Suggest formula corrections based on common errors
 */
export function suggestCorrections(formula: string): string[] {
  const suggestions: string[] = [];

  // Check for common typos
  if (formula.includes("VLOOKUP")) {
    suggestions.push("Did you mean VLOOKUP? Check the syntax: =VLOOKUP(lookup_value, table_array, col_index_num, [range_lookup])");
  }

  if (formula.includes("SUMIF")) {
    suggestions.push("SUMIF syntax: =SUMIF(range, criteria, [sum_range])");
  }

  // Check for missing function names
  if (formula.includes("(") && !formula.match(/[A-Z]+\(/)) {
    suggestions.push("Formula appears to be missing a function name");
  }

  return suggestions;
}

/**
 * Parse a formula into its components
 */
export function parseFormula(formula: string): {
  functionName: string;
  arguments: string[];
  cellReferences: string[];
} {
  const functionMatch = formula.match(/=([A-Z]+)\((.*)\)/i);

  if (!functionMatch) {
    return { functionName: "", arguments: [], cellReferences: [] };
  }

  const functionName = functionMatch[1];
  const argsString = functionMatch[2];

  // Simple argument parsing (doesn't handle nested functions perfectly)
  const arguments_ = argsString.split(",").map((arg) => arg.trim());
  const cellReferences = extractCellReferences(formula);

  return {
    functionName,
    arguments: arguments_,
    cellReferences,
  };
}
