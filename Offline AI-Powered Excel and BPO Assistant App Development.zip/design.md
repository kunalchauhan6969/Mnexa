# M-Nexa AI - Mobile App Design Document

## Overview

M-Nexa AI is an offline-first Android application designed for professionals in BPO, data analysis, and Excel operations. The app provides intelligent assistance through an embedded LLM, OCR-based visual analysis, and comprehensive educational resources—all without requiring internet connectivity.

---

## Screen List

1. **Splash/Onboarding Screen** — Initial app load with branding
2. **Home Screen** — Main hub with quick access to core features
3. **Scan & Solve Screen** — Camera/gallery upload for Excel sheet analysis
4. **Scan Results Screen** — Display OCR extraction, error analysis, and corrected formulas
5. **Learn Hub Screen** — Search and browse BPO/Excel knowledge base
6. **Article/Definition Screen** — Detailed content for BPO terms and Excel formulas
7. **Settings Screen** — App preferences, offline data status, about
8. **Chat/Query Screen** — Text-based AI assistant for general questions

---

## Primary Content and Functionality

### Screen 1: Splash/Onboarding
- **Content**: M-Nexa AI logo, app tagline ("Your Offline AI Excel & BPO Assistant")
- **Functionality**: Auto-dismiss after 2 seconds; navigate to Home

### Screen 2: Home Screen
- **Content**:
  - Header: App name + greeting ("Welcome back, User")
  - Three main action cards:
    - "Scan & Solve" — Camera icon, "Analyze Excel sheets"
    - "Learn" — Book icon, "BPO & Excel knowledge base"
    - "Ask AI" — Chat icon, "Text-based queries"
  - Quick stats: "Scans today", "Formulas learned", "Offline status"
  - Recent activity list (last 3 scans/queries)
- **Functionality**: Tap cards to navigate to respective screens

### Screen 3: Scan & Solve
- **Content**:
  - Large camera preview area or image placeholder
  - Two buttons: "Take Photo" (camera) and "Upload from Gallery"
  - Processing indicator (spinner) while OCR runs
- **Functionality**: 
  - Capture/select image → trigger OCR
  - Extract text and numbers from image
  - Pass extracted data to offline LLM for analysis

### Screen 4: Scan Results
- **Content**:
  - Extracted data display (table or formatted text)
  - Analysis section:
    - Identified errors (highlighted in red)
    - Corrected formula (highlighted in green)
    - Explanation: "Why this error occurred"
    - Suggested fix with step-by-step breakdown
  - Action buttons: "Copy Formula", "Save Result", "Scan Again"
- **Functionality**: 
  - Display OCR results
  - Show LLM analysis and corrections
  - Allow user to copy corrected formula to clipboard

### Screen 5: Learn Hub
- **Content**:
  - Search bar at top ("Search BPO terms or Excel formulas")
  - Two tabs: "BPO Dictionary" and "Excel Masterclass"
  - List of topics/formulas with brief descriptions
  - Each item shows: title, category, preview text
- **Functionality**:
  - Search filters results in real-time
  - Tap item to view full article/definition
  - Offline data fully available

### Screen 6: Article/Definition
- **Content**:
  - Title (e.g., "Forecasting", "VLOOKUP")
  - Category badge (e.g., "BPO Concept", "Excel Formula")
  - Full definition/explanation with examples
  - For Excel formulas: syntax, parameters, real-world examples
  - For BPO terms: definition, context, related metrics
  - Related topics section (links to similar articles)
- **Functionality**:
  - Scroll through content
  - Tap related topics to navigate
  - Bookmark for offline reading

### Screen 7: Settings
- **Content**:
  - App version and build info
  - Offline status indicator (green = all data cached)
  - Data management: "Clear cache", "Export results"
  - About section with app description
  - Contact/feedback option
- **Functionality**:
  - Toggle dark/light mode
  - Manage offline data
  - View app information

### Screen 8: Chat/Query Screen
- **Content**:
  - Chat history display (messages and responses)
  - Text input field at bottom ("Ask a question...")
  - Send button
- **Functionality**:
  - User types query → LLM processes offline
  - Display response in chat format
  - Maintain conversation history

---

## Key User Flows

### Flow 1: Scan & Solve Excel Sheet
1. User taps "Scan & Solve" on Home
2. App opens camera or gallery picker
3. User captures/selects Excel sheet image
4. OCR extracts text and numbers
5. LLM analyzes for errors and logic issues
6. Results screen displays:
   - Extracted data
   - Identified errors (if any)
   - Corrected formula
   - Explanation of the fix
7. User can copy formula or scan another sheet

### Flow 2: Learn BPO/Excel Concepts
1. User taps "Learn" on Home
2. Learn Hub screen displays BPO Dictionary and Excel Masterclass tabs
3. User searches for term (e.g., "Forecasting" or "VLOOKUP")
4. Matching results appear in list
5. User taps result to view full article
6. Article screen shows definition, examples, and related topics
7. User can bookmark or navigate to related articles

### Flow 3: Ask AI Questions
1. User taps "Ask AI" on Home
2. Chat screen opens with input field
3. User types question (e.g., "How do I calculate AHT?")
4. LLM processes query offline and responds
5. Response appears in chat history
6. User can ask follow-up questions

---

## Color Choices

### Brand Colors (M-Nexa AI)
- **Primary**: `#0A7EA4` (Professional Blue) — Main actions, highlights
- **Secondary**: `#F59E0B` (Amber) — Warnings, alerts, secondary actions
- **Success**: `#22C55E` (Green) — Correct formulas, success states
- **Error**: `#EF4444` (Red) — Errors, incorrect formulas
- **Background**: `#FFFFFF` (Light) / `#151718` (Dark)
- **Surface**: `#F5F5F5` (Light) / `#1E2022` (Dark) — Cards, containers
- **Text**: `#11181C` (Light) / `#ECEDEE` (Dark) — Primary text
- **Muted**: `#687076` (Light) / `#9BA1A6` (Dark) — Secondary text

### Usage
- **Primary Blue**: Header, main buttons, active states
- **Amber**: Warning badges, secondary actions
- **Green**: Correct formulas, success messages
- **Red**: Errors, incorrect formulas, alerts
- **Surfaces**: Cards for scans, articles, chat messages

---

## Layout Principles

### Mobile Portrait (9:16) & One-Handed Usage
- **Header**: Compact, sticky at top (app name, status indicator)
- **Content**: Scrollable, centered, with generous padding (16-24px)
- **Buttons**: Large touch targets (48-56px height), positioned at bottom or within reach
- **Cards**: Full-width or slightly inset, rounded corners (12-16px)
- **Text**: Clear hierarchy (headers 24-32px, body 16px, captions 12-14px)
- **Tab Bar**: Fixed at bottom, 5 icons max (Home, Scan, Learn, Chat, Settings)

### Safe Area Handling
- Content respects notch and home indicator areas
- Tab bar accounts for bottom safe area on devices with home indicator

---

## Navigation Structure

```
Home (Tab 1)
├── Scan & Solve (Tab 2)
│   ├── Camera/Gallery
│   └── Scan Results
├── Learn (Tab 3)
│   ├── Learn Hub (Search, BPO/Excel tabs)
│   └── Article/Definition Detail
├── Chat (Tab 4)
│   └── Chat Screen
└── Settings (Tab 5)
    └── Settings Screen
```

---

## Offline-First Architecture

- **Embedded LLM**: Quantized model (TensorFlow Lite or ONNX) bundled in APK
- **OCR**: ML Kit on-device text recognition (no cloud calls)
- **Knowledge Base**: Pre-loaded BPO dictionary and Excel formula database (SQLite or JSON)
- **No Internet Required**: All processing happens locally on device
- **Data Storage**: AsyncStorage for user history, SQLite for knowledge base

---

## Accessibility & Usability

- **Font Sizes**: Minimum 14px for body text, 12px for captions
- **Color Contrast**: WCAG AA compliance (4.5:1 for text)
- **Touch Targets**: Minimum 48x48dp for interactive elements
- **Labels**: All buttons and icons have descriptive labels
- **Dark Mode**: Full support with automatic theme switching

---

## Performance Considerations

- **App Size**: Keep under 100MB (quantized LLM + knowledge base)
- **Load Time**: Splash screen → Home in under 2 seconds
- **OCR Processing**: Limit image size to 2048x2048px for fast processing
- **LLM Response**: Target under 3 seconds for typical queries
- **Memory**: Optimize for devices with 2GB+ RAM (Android 10+)

---

## Future Enhancements

- Voice input for queries ("Ask AI" via speech-to-text)
- Export results to PDF or Excel
- Sync results to cloud (optional, user-initiated)
- Collaborative features (share scans with team)
- Advanced formula suggestions based on data patterns
- Integration with actual Excel files (via file picker)
