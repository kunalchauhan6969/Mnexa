import { ScrollView, Text, View, TouchableOpacity, Pressable } from "react-native";
import { useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useColors } from "@/hooks/use-colors";
import * as Haptics from "expo-haptics";

/**
 * Home Screen - M-Nexa AI Main Hub
 * 
 * Displays three main action cards:
 * - Scan & Solve: Analyze Excel sheets via camera/gallery
 * - Learn: Browse BPO and Excel knowledge base
 * - Ask AI: Chat with the offline AI assistant
 */
export default function HomeScreen() {
  const router = useRouter();
  const colors = useColors();

  const handleActionPress = (action: 'scan' | 'learn' | 'chat') => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    router.push(`/(tabs)/${action}` as any);
  };

  const ActionCard = ({
    icon,
    title,
    subtitle,
    action,
  }: {
    icon: 'camera.fill' | 'book.fill' | 'bubble.left.and.bubble.right.fill';
    title: string;
    subtitle: string;
    action: 'scan' | 'learn' | 'chat';
  }) => (
    <Pressable
      onPress={() => handleActionPress(action)}
      style={({ pressed }) => [
        {
          opacity: pressed ? 0.7 : 1,
          transform: [{ scale: pressed ? 0.98 : 1 }],
        },
      ]}
    >
      <View className="bg-surface rounded-2xl p-6 mb-4 border border-border shadow-sm">
        <View className="flex-row items-center gap-4">
          <View
            className="w-16 h-16 rounded-xl items-center justify-center"
            style={{ backgroundColor: colors.primary }}
          >
            <IconSymbol name={icon as any} size={32} color="#FFFFFF" />
          </View>
          <View className="flex-1">
            <Text className="text-lg font-semibold text-foreground">{title}</Text>
            <Text className="text-sm text-muted mt-1">{subtitle}</Text>
          </View>
          <IconSymbol name="chevron.right" size={24} color={colors.muted} />
        </View>
      </View>
    </Pressable>
  );

  return (
    <ScreenContainer className="p-6">
      <ScrollView
        contentContainerStyle={{ flexGrow: 1 }}
        showsVerticalScrollIndicator={false}
      >
        <View className="flex-1 gap-2">
          {/* Header Section */}
          <View className="mb-6">
            <Text className="text-3xl font-bold text-foreground">M-Nexa AI</Text>
            <Text className="text-base text-muted mt-2">
              Your Offline AI Excel & BPO Assistant
            </Text>
          </View>

          {/* Quick Stats */}
          <View className="flex-row gap-3 mb-8">
            <View className="flex-1 bg-surface rounded-xl p-4 border border-border">
              <Text className="text-xs text-muted">Scans Today</Text>
              <Text className="text-2xl font-bold text-foreground mt-1">0</Text>
            </View>
            <View className="flex-1 bg-surface rounded-xl p-4 border border-border">
              <Text className="text-xs text-muted">Offline Status</Text>
              <View className="flex-row items-center gap-1 mt-1">
                <View className="w-2 h-2 rounded-full bg-success" />
                <Text className="text-sm font-semibold text-success">Ready</Text>
              </View>
            </View>
          </View>

          {/* Action Cards */}
          <View className="mb-4">
            <Text className="text-sm font-semibold text-muted uppercase tracking-wider mb-4">
              Main Features
            </Text>
            <ActionCard
              icon="camera.fill"
              title="Scan & Solve"
              subtitle="Analyze Excel sheets"
              action="scan"
            />
            <ActionCard
              icon="book.fill"
              title="Learn"
              subtitle="BPO & Excel knowledge base"
              action="learn"
            />
            <ActionCard
              icon="bubble.left.and.bubble.right.fill"
              title="Ask AI"
              subtitle="Text-based queries"
              action="chat"
            />
          </View>

          {/* Recent Activity Section */}
          <View className="mt-6 pt-6 border-t border-border">
            <Text className="text-sm font-semibold text-muted uppercase tracking-wider mb-4">
              Recent Activity
            </Text>
            <View className="bg-surface rounded-xl p-4 border border-border items-center justify-center py-8">
              <IconSymbol name="lightbulb.fill" size={32} color={colors.muted} />
              <Text className="text-sm text-muted mt-2 text-center">
                No recent scans or queries yet
              </Text>
              <Text className="text-xs text-muted mt-1 text-center">
                Get started by scanning an Excel sheet or asking a question
              </Text>
            </View>
          </View>

          {/* Info Banner */}
          <View className="mt-6 bg-blue-100 rounded-xl p-4 border border-blue-200">
            <View className="flex-row gap-3">
              <IconSymbol name="lightbulb.fill" size={20} color="#3B82F6" />
              <View className="flex-1">
                <Text className="text-xs font-semibold text-foreground">
                  Tip: All processing happens offline
                </Text>
                <Text className="text-xs text-muted mt-1">
                  Your data never leaves your device. No internet required.
                </Text>
              </View>
            </View>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
