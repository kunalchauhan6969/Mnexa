# M-Nexa AI - Project TODO

## Phase 1: Core App Structure & Navigation
- [x] Setup app branding (logo, colors, app name in app.config.ts)
- [x] Create bottom tab navigation (Home, Scan, Learn, Chat, Settings)
- [x] Design and implement Home screen with action cards
- [x] Create ScreenContainer wrapper for all screens
- [ ] Implement dark/light theme toggle in Settings

## Phase 2: Offline LLM Integration
- [x] Research and select lightweight LLM (TensorFlow Lite or ONNX Runtime)
- [ ] Download and bundle quantized model in assets
- [x] Create LLM inference wrapper/service (mock implementation)
- [x] Test LLM responses for Excel formulas and BPO queries
- [ ] Optimize model loading and caching

## Phase 3: OCR & Scan & Solve Feature
- [x] Create camera capture screen with preview
- [x] Implement gallery image picker (using expo-image-picker)
- [x] Create OCR text extraction pipeline (mock implementation)
- [ ] Create Scan Results screen with error highlighting
- [ ] Implement formula correction logic (LLM → corrected formula)
- [ ] Add copy-to-clipboard functionality
- [ ] Integrate ML Kit for on-device OCR (production)

## Phase 4: BPO Knowledge Base
- [x] Compile BPO dictionary (Scheduling, Forecasting, AHT, Shrinkage, Occupancy, SLA, etc.)
- [x] Create structured data format (in LLM service)
- [x] Implement BPO dictionary search
- [x] Create Article/Definition screen for BPO terms
- [x] Add rich formatting (examples, related topics, metrics)
- [x] Test search and filtering

## Phase 5: Excel Masterclass Module
- [x] Compile Excel formula database (VLOOKUP, SUMIF, Array formulas, etc.)
- [x] Create structured formula data (syntax, parameters, examples)
- [x] Implement Excel formula search
- [x] Create Article/Definition screen for formulas
- [ ] Add visual examples and step-by-step breakdowns
- [ ] Link related formulas and concepts

## Phase 6: Chat/Query AI Feature
- [x] Create Chat screen with message history
- [x] Implement text input and send button
- [x] Integrate LLM for query processing
- [x] Display responses in chat format
- [ ] Persist chat history locally (AsyncStorage)
- [x] Add typing indicators and loading states

## Phase 7: Learn Hub & Search
- [x] Create Learn Hub screen with BPO/Excel tabs
- [x] Implement unified search across both databases
- [ ] Add filtering and sorting options
- [x] Create list view with preview text
- [x] Implement navigation to detail screens
- [ ] Add bookmarking feature

## Phase 8: Settings & Data Management
- [ ] Create Settings screen
- [ ] Add offline status indicator
- [ ] Implement cache management (clear cache, view size)
- [ ] Add app version and about information
- [ ] Create feedback/contact option
- [ ] Add data export functionality (optional)

## Phase 9: UI/UX Polish
- [ ] Implement loading indicators and spinners
- [ ] Add error handling and user-friendly messages
- [ ] Create smooth transitions between screens
- [ ] Add haptic feedback for interactions
- [ ] Optimize images and assets for app size
- [ ] Test responsive design on various screen sizes

## Phase 10: Testing & Optimization
- [ ] Unit tests for LLM inference
- [ ] Unit tests for OCR processing
- [ ] Integration tests for user flows
- [ ] Performance testing (app startup, LLM response time)
- [ ] Memory usage optimization
- [ ] Battery usage optimization
- [ ] Test on real Android devices

## Phase 11: APK Build & Deployment
- [ ] Configure Android build settings
- [ ] Generate signed APK
- [ ] Test APK on physical device
- [ ] Create release notes
- [ ] Prepare app store listing (if applicable)
- [ ] Final QA and bug fixes

## Phase 12: Documentation & Delivery
- [ ] Create user guide/help documentation
- [ ] Document LLM and OCR capabilities
- [ ] Create troubleshooting guide
- [ ] Prepare technical documentation for future maintenance
- [ ] Deliver APK and documentation to user
