import { ScrollView, Text, View, TouchableOpacity, ActivityIndicator, Alert } from "react-native";
import { useState } from "react";
import { useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useColors } from "@/hooks/use-colors";
import * as ImagePicker from "expo-image-picker";
import * as Haptics from "expo-haptics";

/**
 * Scan & Solve Screen
 * 
 * Allows users to:
 * - Take a photo of an Excel sheet using the camera
 * - Upload an image from the device gallery
 * - Process the image with OCR and LLM
 */
export default function ScanScreen() {
  const router = useRouter();
  const colors = useColors();
  const [isProcessing, setIsProcessing] = useState(false);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);

  const requestCameraPermission = async () => {
    const { status } = await ImagePicker.requestCameraPermissionsAsync();
    return status === "granted";
  };

  const requestGalleryPermission = async () => {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    return status === "granted";
  };

  const handleTakePhoto = async () => {
    const hasPermission = await requestCameraPermission();
    if (!hasPermission) {
      Alert.alert("Permission Denied", "Camera permission is required to scan Excel sheets.");
      return;
    }

    try {
      const result = await ImagePicker.launchCameraAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        quality: 0.8,
        aspect: [4, 3],
      });

      if (!result.canceled && result.assets[0]) {
        handleImageSelected(result.assets[0].uri);
      }
    } catch (error) {
      Alert.alert("Error", "Failed to access camera. Please try again.");
    }
  };

  const handlePickFromGallery = async () => {
    const hasPermission = await requestGalleryPermission();
    if (!hasPermission) {
      Alert.alert("Permission Denied", "Gallery permission is required to select images.");
      return;
    }

    try {
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        quality: 0.8,
        aspect: [4, 3],
      });

      if (!result.canceled && result.assets[0]) {
        handleImageSelected(result.assets[0].uri);
      }
    } catch (error) {
      Alert.alert("Error", "Failed to access gallery. Please try again.");
    }
  };

  const handleImageSelected = async (imageUri: string) => {
    setSelectedImage(imageUri);
    setIsProcessing(true);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);

    // Simulate OCR and LLM processing
    // In production, this would call native ML Kit OCR and the embedded LLM
    setTimeout(() => {
      setIsProcessing(false);
      // Navigate to results screen with the image
      router.push({
        pathname: "/(tabs)/scan-results",
        params: { imageUri },
      } as any);
    }, 2000);
  };

  return (
    <ScreenContainer className="p-6">
      <ScrollView
        contentContainerStyle={{ flexGrow: 1 }}
        showsVerticalScrollIndicator={false}
      >
        <View className="flex-1 gap-6">
          {/* Header */}
          <View>
            <Text className="text-2xl font-bold text-foreground">Scan & Solve</Text>
            <Text className="text-sm text-muted mt-2">
              Capture or upload an Excel sheet to analyze formulas and identify errors
            </Text>
          </View>

          {/* Preview Area */}
          <View
            className="w-full aspect-square rounded-2xl border-2 border-dashed items-center justify-center bg-surface"
            style={{ borderColor: colors.border }}
          >
            {selectedImage ? (
              <View className="w-full h-full rounded-2xl overflow-hidden">
                {/* Image preview would go here */}
                <View className="w-full h-full bg-muted/10 items-center justify-center">
                  <IconSymbol name="photo" size={48} color={colors.muted} />
                  <Text className="text-sm text-muted mt-2">Image loaded</Text>
                </View>
              </View>
            ) : isProcessing ? (
              <View className="items-center gap-3">
                <ActivityIndicator size="large" color={colors.primary} />
                <Text className="text-sm text-muted">Processing image...</Text>
              </View>
            ) : (
              <View className="items-center gap-2">
                <IconSymbol name="camera.fill" size={48} color={colors.primary} />
                <Text className="text-base font-semibold text-foreground">
                  No image selected
                </Text>
                <Text className="text-xs text-muted text-center">
                  Take a photo or upload from gallery
                </Text>
              </View>
            )}
          </View>

          {/* Action Buttons */}
          <View className="gap-3">
            <TouchableOpacity
              onPress={handleTakePhoto}
              disabled={isProcessing}
              className="bg-primary rounded-xl py-4 px-6 items-center justify-center active:opacity-80"
            >
              <View className="flex-row items-center gap-2">
                <IconSymbol name="camera.fill" size={20} color="#FFFFFF" />
                <Text className="text-white font-semibold">Take Photo</Text>
              </View>
            </TouchableOpacity>

            <TouchableOpacity
              onPress={handlePickFromGallery}
              disabled={isProcessing}
              className="bg-surface border border-border rounded-xl py-4 px-6 items-center justify-center active:opacity-80"
            >
              <View className="flex-row items-center gap-2">
                <IconSymbol name="photo" size={20} color={colors.primary} />
                <Text className="font-semibold" style={{ color: colors.primary }}>
                  Upload from Gallery
                </Text>
              </View>
            </TouchableOpacity>
          </View>

          {/* Info Section */}
          <View className="bg-surface rounded-xl p-4 border border-border gap-3">
            <View className="flex-row gap-2">
              <IconSymbol name="lightbulb.fill" size={16} color={colors.muted} />
              <Text className="text-xs text-muted flex-1">
                <Text className="font-semibold">Tip:</Text> Take clear photos of Excel sheets with good lighting for best results
              </Text>
            </View>
            <View className="flex-row gap-2">
              <IconSymbol name="checkmark" size={16} color={colors.success} />
              <Text className="text-xs text-muted flex-1">
                All processing happens offline on your device
              </Text>
            </View>
          </View>

          {/* Recent Scans */}
          <View>
            <Text className="text-sm font-semibold text-muted uppercase tracking-wider mb-3">
              Recent Scans
            </Text>
            <View className="bg-surface rounded-xl p-4 border border-border items-center justify-center py-6">
              <IconSymbol name="photo" size={32} color={colors.muted} />
              <Text className="text-sm text-muted mt-2">No recent scans</Text>
            </View>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
