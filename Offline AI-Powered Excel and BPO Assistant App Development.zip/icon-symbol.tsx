// Fallback for using MaterialIcons on Android and web.

import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { SymbolWeight, SymbolViewProps } from "expo-symbols";
import { ComponentProps } from "react";
import { OpaqueColorValue, type StyleProp, type TextStyle } from "react-native";

type IconMapping = Record<SymbolViewProps["name"], ComponentProps<typeof MaterialIcons>["name"]>;

/**
 * Add your SF Symbols to Material Icons mappings here.
 * - see Material Icons in the [Icons Directory](https://icons.expo.fyi).
 * - see SF Symbols in the [SF Symbols](https://developer.apple.com/sf-symbols/) app.
 */
const MAPPING = {
  "house.fill": "home",
  "paperplane.fill": "send",
  "chevron.left.forwardslash.chevron.right": "code",
  "chevron.right": "chevron-right",
  "camera.fill": "camera-alt",
  "book.fill": "school",
  "bubble.left.and.bubble.right.fill": "chat",
  "gear": "settings",
  "xmark": "close",
  "checkmark": "check",
  "plus": "add",
  "magnifyingglass": "search",
  "arrow.left": "arrow-back",
  "arrow.right": "arrow-forward",
  "square.and.arrow.up": "share",
  "doc.text": "description",
  "photo": "image",
  "lightbulb.fill": "lightbulb",
} as IconMapping;

type IconSymbolName = keyof typeof MAPPING;

/**
 * Get the Material Icons name for a given SF Symbol name.
 * Useful for dynamic icon selection.
 */
export function getIconName(sfSymbol: IconSymbolName): string {
  return MAPPING[sfSymbol] || "help";
}

/**
 * List of all available icon names for reference.
 */
export const AVAILABLE_ICONS = Object.keys(MAPPING) as IconSymbolName[];

/**
 * An icon component that uses native SF Symbols on iOS, and Material Icons on Android and web.
 * This ensures a consistent look across platforms, and optimal resource usage.
 * Icon `name`s are based on SF Symbols and require manual mapping to Material Icons.
 * 
 * Usage:
 * ```tsx
 * <IconSymbol name="camera.fill" size={24} color="#0A7EA4" />
 * ```
 */
export function IconSymbol({
  name,
  size = 24,
  color,
  style,
}: {
  name: IconSymbolName;
  size?: number;
  color: string | OpaqueColorValue;
  style?: StyleProp<TextStyle>;
  weight?: SymbolWeight;
}) {
  const iconName = MAPPING[name];
  if (!iconName) {
    console.warn(`Icon "${name}" not found in mapping`);
    return null;
  }
  return <MaterialIcons color={color} size={size} name={iconName} style={style} />;
}
